const CACHE_NAME = 'p3k-offline-v2';

// 1. Saat pertama kali dibuka (Online), simpan halaman utama
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('Mencache halaman utama...');
      return cache.addAll(['./', './index.html']);
    })
  );
});

// 2. Simpan gambar secara otomatis saat user browsing
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      // Jika gambar/file sudah ada di cache, langsung ambil dari sana
      if (response) {
        return response;
      }
      
      // Jika belum ada di cache, ambil dari internet
      return fetch(event.request).then((networkResponse) => {
        // Cek apakah datanya valid
        if (!networkResponse || networkResponse.status !== 200) {
          return networkResponse;
        }
        
        // Simpan ke dalam cache untuk dipakai nanti saat offline
        const responseToCache = networkResponse.clone();
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache);
        });
        
        return networkResponse;
      });
    })
  );
});